(function (blocks, editor, i18n, element, components) {
    var __ = i18n.__;
    var el = element.createElement;
    var registerBlockType = blocks.registerBlockType;
    var MediaUpload = editor.MediaUpload;
    var RichText = editor.RichText;
    var TextControl = components.TextControl;

    registerBlockType('banner-module/banner-block', {
        title: __('Banner Module'),
        icon: 'format-image',
        category: 'common',
        attributes: {
            title: {
                type: 'string',
                source: 'html',
                selector: 'h2',
            },
            subtitle: {
                type: 'string',
                source: 'html',
                selector: 'p',
            },
            image: {
                type: 'string',
            },
            ctaText: {
                type: 'string',
            },
            ctaLink: {
                type: 'string',
            },
        },

        edit: function (props) {
            var attributes = props.attributes;

            function updateTitle(newTitle) {
                props.setAttributes({ title: newTitle });
            }

            function updateSubtitle(newSubtitle) {
                props.setAttributes({ subtitle: newSubtitle });
            }

            function onSelectImage(newImage) {
                props.setAttributes({ image: newImage.url });
            }

            function onRemoveImage() {
                props.setAttributes({ image: '' });
            }

            function updateCTAText(newCTAText) {
                props.setAttributes({ ctaText: newCTAText });
            }

            function updateCTALink(newCTALink) {
                props.setAttributes({ ctaLink: newCTALink });
            }

            return el('div', { className: 'banner-module' },
                el(RichText, {
                    tagName: 'h2',
                    value: attributes.title,
                    onChange: updateTitle,
                    placeholder: __('Enter Title...'),
                }),
                el(RichText, {
                    tagName: 'p',
                    value: attributes.subtitle,
                    onChange: updateSubtitle,
                    placeholder: __('Enter Subtitle...'),
                }),
                el('div', { className: 'banner-image-container' },
                    el('img', { src: attributes.image, alt: __('Banner Image'), style: { maxWidth: '100%' } }),
                    el(MediaUpload, {
                        onSelect: onSelectImage,
                        type: 'image',
                        value: attributes.image,
                        render: function (obj) {
                            return el(components.Button, {
                                onClick: obj.open,
                                className: 'button button-large',
                            }, __('Add Image'));
                        },
                    }),
                    attributes.image &&
                    el(components.Button, {
                        onClick: onRemoveImage,
                        className: 'button button-small',
                    }, __('Remove Image'))
                ),
                el(TextControl, {
                    label: __('CTA Button Text'),
                    value: attributes.ctaText,
                    onChange: updateCTAText,
                    placeholder: __('Enter Button Text...'),
                }),
                el(TextControl, {
                    label: __('CTA Button Link'),
                    value: attributes.ctaLink,
                    onChange: updateCTALink,
                    placeholder: __('Enter Button Link...'),
                })
            );
        },

        save: function (props) {
            var attributes = props.attributes;

            return el('div', { className: 'banner-module' },
                el('h2', { dangerouslySetInnerHTML: { __html: attributes.title } }),
                el('p', { dangerouslySetInnerHTML: { __html: attributes.subtitle } }),
                attributes.image && el('img', { src: attributes.image, alt: __('Banner Image'), style: { maxWidth: '100%' } }),
                el('a', { href: attributes.ctaLink, className: 'button' }, attributes.ctaText)
            );
        },
    });
})(
    window.wp.blocks,
    window.wp.editor,
    window.wp.i18n,
    window.wp.element,
    window.wp.components
);

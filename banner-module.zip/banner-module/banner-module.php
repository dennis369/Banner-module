<?php
/*
Plugin Name: Banner Module
Plugin URI: your-plugin-uri
Description: A custom banner module for WordPress.
Version: 1.0
Author: Your Name
Author URI: your-website-url
License: GPL2
*/

// Enqueue block editor assets
function banner_module_block_editor_assets() {
    wp_enqueue_script(
        'banner-module-block-editor',
        plugins_url('block-editor.js', __FILE__),
        array('wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-components', 'wp-api')
    );

    // Enqueue the CSS file for the frontend styles
    wp_enqueue_style(
        'banner-module-frontend-styles',
        plugins_url('frontend-styles.css', __FILE__),
        array(),
        '1.0.0'
    );
}
add_action('enqueue_block_editor_assets', 'banner_module_block_editor_assets');

// Register the custom block category
function banner_module_block_category($categories, $post) {
    return array_merge(
        $categories,
        array(
            array(
                'slug' => 'banner-module',
                'title' => 'Banner Module',
                'icon' => 'star-filled',
            ),
        )
    );
}
add_filter('block_categories', 'banner_module_block_category', 10, 2);
